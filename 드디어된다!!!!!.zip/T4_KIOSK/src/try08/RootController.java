package try08;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class RootController implements Initializable {
	@FXML private TextField americano;
	@FXML private TextField cafelatte;
	@FXML private TextField espresso;
	@FXML private TextField milk;
	@FXML private TextField bread;
	@FXML private TextField cake;
	@FXML private TextField cookie;
	@FXML private TextField macaroon;
	@FXML private TextField icetea;
	@FXML private TextField chocolatelatte;
	@FXML private Label orderlist;
	@FXML private Button order;
	@FXML private Button exit;
	@FXML private TextField name;
	@FXML private TextField phonenumber;
	@FXML private Button savepoint;
	@FXML private Button viewpoint;
	
	public void handleOrderAction(ActionEvent event) {
		String americanoCnt = americano.getText();
		System.out.println("아메리카노 주문 개수 : " + americanoCnt);
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}

}
