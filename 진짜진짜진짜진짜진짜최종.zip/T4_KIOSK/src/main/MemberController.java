package main;

import java.net.URL;
import java.util.ResourceBundle;

import data_model.KioskDAO;
import data_model.KioskDTO;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class MemberController implements Initializable {
	
	@FXML private Label memberlist;
	@FXML private TextField name;
	@FXML private TextField phonenumber;
	@FXML private Button savepoint;
	@FXML private Button joinmember;
	@FXML private Button viewpoint;
	
	public void handleSavepointAction(ActionEvent event) {
		if(name.getText().trim().isEmpty()) {
			Platform.runLater(new Runnable() {
				@Override
				public void run() {		
					memberlist.setText("공백은 입력이 되지 않습니다.\n제대로된 값을 입력하세요.");
				}
			});
		}
		else if(phonenumber.getText().trim().isEmpty()) {
			Platform.runLater(new Runnable() {
				@Override
				public void run() {		
					memberlist.setText("공백은 입력이 되지 않습니다.\n제대로된 값을 입력하세요.");
				}
			});
		}
		else {
			String guest_name = name.getText();
			String guest_phone = phonenumber.getText();
			
			KioskDAO kioskDAO = new KioskDAO();
			
			if(!(kioskDAO.memberFindOne(guest_phone))) {
				Platform.runLater(new Runnable() {
					@Override
					public void run() {		
						memberlist.setText("회원을 조회할 수 없습니다. 회원가입을 먼저 해주세요.");
					}
				});
				return;
			}
	
			int point = RootController.total;
			KioskDTO savePointDTO = new KioskDTO(guest_phone, point);
			kioskDAO.savePoint(savePointDTO);
			
			Platform.runLater(new Runnable() {
	
				@Override
				public void run() {
					if(point > 0) {
						memberlist.setText(guest_name + "님,\n멤버십 포인트 " + point + "원 적립되었습니다.");
						RootController.total = 0;
					}
					else {
						memberlist.setText("주문을 먼저 해주세요.");
						RootController.total = 0;
					}
				}
			});
		}
	}
	
	public void handleJoinmemberAction(ActionEvent event) {
		if(name.getText().trim().isEmpty()) {
			Platform.runLater(new Runnable() {
				@Override
				public void run() {		
					memberlist.setText("공백은 입력이 되지 않습니다.\n제대로된 값을 입력하세요.");
				}
			});
		}
		else if(phonenumber.getText().trim().isEmpty()) {
			Platform.runLater(new Runnable() {
				@Override
				public void run() {		
					memberlist.setText("공백은 입력이 되지 않습니다.\n제대로된 값을 입력하세요.");
				}
			});
		}
		else {
			String guest_name = name.getText();
			String guest_phone = phonenumber.getText();
			
			KioskDAO kioskDAO = new KioskDAO();
			KioskDTO setMemberDTO = new KioskDTO(guest_name, guest_phone);
			
			if(!(kioskDAO.memberFindOne(guest_phone))) {
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						kioskDAO.setMember(setMemberDTO);
						memberlist.setText(guest_name + "님, 회원가입되었습니다.");
					}
				});
			}
			else {
				Platform.runLater(new Runnable() {
					@Override
					public void run() {		
						memberlist.setText("이미 가입된 회원입니다.");
					}
				});
			}
		}

	}
	
	public void handleViewpointAction(ActionEvent event) {
		if(name.getText().trim().isEmpty()) {
			Platform.runLater(new Runnable() {
				@Override
				public void run() {		
					memberlist.setText("공백은 입력이 되지 않습니다.\n제대로된 값을 입력하세요.");
				}
			});
		}
		else if(phonenumber.getText().trim().isEmpty()) {
			Platform.runLater(new Runnable() {
				@Override
				public void run() {		
					memberlist.setText("공백은 입력이 되지 않습니다.\n제대로된 값을 입력하세요.");
				}
			});
		}
		else {
			String guest_name = name.getText();
			String guest_phone = phonenumber.getText();
			
			KioskDAO kioskDAO = new KioskDAO();
			KioskDTO viewMemberDTO = new KioskDTO(guest_name, guest_phone);
			
			if(kioskDAO.memberFindOne(guest_phone)) {
				String point = kioskDAO.viewPoint(viewMemberDTO);
				Platform.runLater(new Runnable() {
					@Override
					public void run() {		
						memberlist.setText(point);
					}
				});
			}
			else {
				Platform.runLater(new Runnable() {
					@Override
					public void run() {		
						memberlist.setText("회원을 조회할 수 없습니다.");
					}
				});
			}
		}
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
	}

}
