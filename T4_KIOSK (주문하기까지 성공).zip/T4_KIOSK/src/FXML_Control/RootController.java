package FXML_Control;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import DATA_MODEL.KioskDAO;
import DATA_MODEL.KioskDTO;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;

public class RootController implements Initializable {

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}
	
	public void handleAmericanoAction(ActionEvent event) {
		americanoCnt++;
	}
	public void handleCafelatteAction(ActionEvent event) {
		cafelatteCnt++;
	}
	public void handleEspressoAction(ActionEvent event) {
		espressoCnt++;
	}
	public void handleMilkAction(ActionEvent event) {
		milkCnt++;
	}
	public void handleBreadAction(ActionEvent event) {
		breadCnt++;
	}
	public void handleCakeAction(ActionEvent event) {
		cakeCnt++;
	}
	public void handleCookieAction(ActionEvent event) {
		cookieCnt++;
	}
	public void handleMacaroonAction(ActionEvent event) {
		macaroonCnt++;
	}
	public void handleIceteaAction(ActionEvent event) {
		iceteaCnt++;
	}
	public void handleChocolatelatteAction(ActionEvent event) {
		chocolatelatteCnt++;
	}
	
	public void handleOrderAction(ActionEvent event) {
		
		if (americanoCnt > 0) {
			KioskDTO newOrderDTO = new KioskDTO("101", "101", "아메리카노", 4000, americanoCnt);
			kioskArrayList.add(newOrderDTO);
			KioskDTO newStockDTO = new KioskDTO(2*americanoCnt, 201);
			stockArrayList.add(newStockDTO);
		}
		if (cafelatteCnt > 0) {
			KioskDTO newOrderDTO = new KioskDTO("102", "102", "카페라떼", 5000, cafelatteCnt);
			kioskArrayList.add(newOrderDTO);
			KioskDTO newStockDTO01 = new KioskDTO(1*cafelatteCnt, 201);
			KioskDTO newStockDTO02 = new KioskDTO(1*cafelatteCnt, 202);
			stockArrayList.add(newStockDTO01);
			stockArrayList.add(newStockDTO02);
		}
		if (espressoCnt > 0) {
			KioskDTO newOrderDTO = new KioskDTO("103", "103", "에스프레소", 6000, espressoCnt);
			kioskArrayList.add(newOrderDTO);
			KioskDTO newStockDTO = new KioskDTO(1*espressoCnt, 201);
			stockArrayList.add(newStockDTO);
		}
		if (milkCnt > 0) {
			KioskDTO newOrderDTO = new KioskDTO("104", "104", "우유", 3000, milkCnt);
			kioskArrayList.add(newOrderDTO);
			KioskDTO newStockDTO = new KioskDTO(1*milkCnt, 202);
			stockArrayList.add(newStockDTO);
		}
		if (breadCnt > 0) {
			KioskDTO newOrderDTO = new KioskDTO("105", "105", "모닝빵", 2000, breadCnt);
			kioskArrayList.add(newOrderDTO);
			KioskDTO newStockDTO = new KioskDTO(1*breadCnt, 203);
			stockArrayList.add(newStockDTO);
		}
		if (cakeCnt > 0) {
			KioskDTO newOrderDTO = new KioskDTO("106", "106", "조각케잌", 6000, cakeCnt);
			kioskArrayList.add(newOrderDTO);
			KioskDTO newStockDTO = new KioskDTO(1*cakeCnt, 204);
			stockArrayList.add(newStockDTO);
		}
		if (cookieCnt > 0) {
			KioskDTO newOrderDTO = new KioskDTO("107", "107", "쿠키", 4000, cookieCnt);
			kioskArrayList.add(newOrderDTO);
			KioskDTO newStockDTO = new KioskDTO(1*cookieCnt, 205);
			stockArrayList.add(newStockDTO);
		}
		if (macaroonCnt > 0) {
			KioskDTO newOrderDTO = new KioskDTO("108", "108", "마카롱", 2500, macaroonCnt);
			kioskArrayList.add(newOrderDTO);
			KioskDTO newStockDTO = new KioskDTO(1*macaroonCnt, 206);
			stockArrayList.add(newStockDTO);
		}
		if (iceteaCnt > 0) {
			KioskDTO newOrderDTO = new KioskDTO("109", "109", "아이스티", 6000, iceteaCnt);
			kioskArrayList.add(newOrderDTO);
			KioskDTO newStockDTO = new KioskDTO(1*iceteaCnt, 208);
			stockArrayList.add(newStockDTO);
		}
		if (chocolatelatteCnt > 0) {
			KioskDTO newOrderDTO = new KioskDTO("110", "110", "초코라떼", 6000, chocolatelatteCnt);
			kioskArrayList.add(newOrderDTO);
			KioskDTO newStockDTO01 = new KioskDTO(1*chocolatelatteCnt, 202);
			KioskDTO newStockDTO02 = new KioskDTO(1*chocolatelatteCnt, 207);
			stockArrayList.add(newStockDTO01);
			stockArrayList.add(newStockDTO02);
		}
		
		for(int i = 0; i < kioskArrayList.size(); i++) {
			kioskDAO.orderInsert(kioskArrayList.get(i));
			kioskDAO.setSettlement(kioskArrayList.get(i));
		}
		for(int i = 0; i < stockArrayList.size(); i++) {
			kioskDAO.setStock(stockArrayList.get(i));
		}
	}
	
	public void handleExitAction(ActionEvent event) {
		Platform.exit();
	}
	
	@FXML public static Button americano;
	@FXML public static Button cafelatte;
	@FXML public static Button espresso;
	@FXML public static Button milk;
	@FXML public static Button bread;
	@FXML public static Button cake;
	@FXML public static Button cookie;
	@FXML public static Button macaroon;
	@FXML public static Button icetea;
	@FXML public static Button chocolatelatte;
	@FXML public static Button order;
	@FXML public static Button exit;
	
	public static int americanoCnt;
	public static int cafelatteCnt;
	public static int espressoCnt;
	public static int milkCnt;
	public static int breadCnt;
	public static int cakeCnt;
	public static int cookieCnt;
	public static int macaroonCnt;
	public static int iceteaCnt;
	public static int chocolatelatteCnt;
	

	public static KioskDAO kioskDAO = new KioskDAO();
	
	public static ArrayList<KioskDTO> kioskArrayList = new ArrayList<KioskDTO>();
	public static ArrayList<KioskDTO> stockArrayList = new ArrayList<KioskDTO>();
	
}
