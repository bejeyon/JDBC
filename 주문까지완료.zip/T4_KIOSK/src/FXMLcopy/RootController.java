// fx:controller="FXML.RootController"

package FXMLcopy;

import java.util.ArrayList;
import java.net.URL;
import java.util.ResourceBundle;

import data_model.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;

public class RootController implements Initializable {
	@FXML public static ComboBox<String> americano;
	@FXML public static ComboBox<String> cafelatte;
	@FXML public static ComboBox<String> espresso;
	@FXML public static ComboBox<String> milk;
	@FXML public static ComboBox<String> bread;
	@FXML public static ComboBox<String> cake;
	@FXML public static ComboBox<String> cookie;
	@FXML public static ComboBox<String> macaroon;
	@FXML public static ComboBox<String> icetea;
	@FXML public static ComboBox<String> chocolatelatte;
	@FXML public static Button order;
	@FXML public static Button exit;
	

	public static KioskDAO kioskDAO = new KioskDAO();
	
	public static ArrayList<KioskDTO> kioskArrayList = new ArrayList<KioskDTO>();
	public static ArrayList<KioskDTO> stockArrayList = new ArrayList<KioskDTO>();
	
	public static int americanoCnt;
	public static int cafelatteCnt;
	public static int espressoCnt;
	public static int milkCnt;
	public static int breadCnt;
	public static int cakeCnt;
	public static int cookieCnt;
	public static int macaroonCnt;
	public static int iceteaCnt;
	public static int chocolatelatteCnt;
	
	public static void createOrder(String order_id, String menu_id, String menu_name, int unit_price, int num_of_sales) {
		KioskDTO newOrderDTO = new KioskDTO(order_id, menu_id, menu_name, unit_price, num_of_sales);
		kioskArrayList.add(newOrderDTO);
	}
	
	public static void createStockConsumption(int consumption_stock, int ingredient_id) {
		KioskDTO newStockDTO = new KioskDTO(consumption_stock, ingredient_id);
		stockArrayList.add(newStockDTO);
	}

	public static void insertSettlement(KioskDTO setSettlementDTO) {
		kioskDAO.setSettlement(setSettlementDTO);
	}
	
	public static boolean memberFindNumber(String phoneNumber) {
		return kioskDAO.memberFindOne(phoneNumber);
	}
	
	public static void memberInsert(String guest_name, String guest_phone) {
		KioskDTO newMemberDTO = new KioskDTO(guest_name, guest_phone);
		kioskDAO.setMember(newMemberDTO);
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
//		americano.setOnAction(new EventHandler<ActionEvent>() {
//			@Override
//			public void handle(ActionEvent event) {
//				
//			}
//		});
		
//      <Button fx:id="americano" text="아메리카노" />
//      <Button fx:id="cafelatte" text="카페라떼" />
//      <Button fx:id="espresso" text="에스프레소" />
//      <Button fx:id="milk" text="우유" />
//      <Button fx:id="bread" text="모닝빵" />
//      <Button fx:id="cake" text="조각케잌" />
//      <Button fx:id="cookie" text="쿠키" />
//      <Button fx:id="macaroon" text="마카롱" />
//      <Button fx:id="icetea" text="아이스티" />
//      <Button fx:id="chocolatelatte" text="초코라떼" />
//      <Button fx:id="order" text="주문하기" />
//      <Button fx:id="exit" text="종료" />
		
		order.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				try {
		    		
		    		//버튼을 누를때 선택 되어진 콤보 박스의 아이템을 문자열로 받는 부분
		        	//혹시 숫자를 사용해야 할 경우에는 숫자로 변환 해야 합니다.
		    		americanoCnt = Integer.parseInt(americano.getValue());
		    		cafelatteCnt = Integer.parseInt(cafelatte.getValue());
		    		espressoCnt = Integer.parseInt(espresso.getValue());
		    		milkCnt = Integer.parseInt(milk.getValue());
		    		breadCnt = Integer.parseInt(bread.getValue());
		    		cakeCnt = Integer.parseInt(cake.getValue());
		    		cookieCnt = Integer.parseInt(cookie.getValue());
		    		macaroonCnt = Integer.parseInt(macaroon.getValue());
		    		iceteaCnt = Integer.parseInt(icetea.getValue());
		    		chocolatelatteCnt = Integer.parseInt(chocolatelatte.getValue());
		        	
		    	}catch(Exception e) {
		    		System.out.println("예외 발생 : "+e.getLocalizedMessage());
		    	}
			}
		});
	
		if (americanoCnt > 0) {
			createOrder("101", "101", "아메리카노", 4000, americanoCnt);
			createStockConsumption(2*americanoCnt, 201);
		}
		if (cafelatteCnt > 0) {
			createOrder("102", "102", "카페라떼", 5000, cafelatteCnt);
			createStockConsumption(1*cafelatteCnt, 201);
			createStockConsumption(1*cafelatteCnt, 202);
		}
		if (espressoCnt > 0) {
			createOrder("103", "103", "에스프레소", 6000, espressoCnt);
			createStockConsumption(1*espressoCnt, 201);
		}
		if (milkCnt > 0) {
			createOrder("104", "104", "우유", 3000, milkCnt);
			createStockConsumption(1*milkCnt, 202);
		}
		if (breadCnt > 0) {
			createOrder("105", "105", "모닝빵", 2000, breadCnt);
			createStockConsumption(1*breadCnt, 203);
		}
		if (cakeCnt > 0) {
			createOrder("106", "106", "조각케잌", 6000, cakeCnt);
			createStockConsumption(1*cakeCnt, 204);
		}
		if (cookieCnt > 0) {
			createOrder("107", "107", "쿠키", 4000, cookieCnt);
			createStockConsumption(1*cookieCnt, 205);
		}
		if (macaroonCnt > 0) {
			createOrder("108", "108", "마카롱", 2500, macaroonCnt);
			createStockConsumption(1*macaroonCnt, 206);
		}
		if (iceteaCnt > 0) {
			createOrder("109", "109", "아이스티", 6000, iceteaCnt);
			createStockConsumption(1*iceteaCnt, 208);
		}
		if (chocolatelatteCnt > 0) {
			createOrder("110", "110", "초코라떼", 6000, chocolatelatteCnt);
			createStockConsumption(1*chocolatelatteCnt, 207);
			createStockConsumption(1*chocolatelatteCnt, 202);
		}
		
		for(int i = 0; i < kioskArrayList.size(); i++) {
			kioskDAO.orderInsert(kioskArrayList.get(i));
			insertSettlement(kioskArrayList.get(i));
		}
		for(int i = 0; i < stockArrayList.size(); i++) {
			kioskDAO.setStock(stockArrayList.get(i));
		}
	}
}