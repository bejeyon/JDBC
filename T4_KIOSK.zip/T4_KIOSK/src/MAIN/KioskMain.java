package MAIN;

import java.util.Scanner;	

public class KioskMain{						
	public static void main(String[] args) {					
		Scanner sc = new Scanner(System.in);					
							
		int ord = 12;	// 사용자가 입력할 메뉴를 저장하는 변수				
		int num = 0;	// 메뉴의 개수를 저장할 변수				
		int x = 0;		// 조건문 안에 들어갈 변수, 음식의 값을 저장하는 변수			
		int total = 0;	// 총 금액				
		String memberID;					
		String memberPW;					
							
		while (ord !=0)	{	//사용자가 메뉴 입력시 0을 입력할 때까지 반복			
			System.out.println("주문하실 메뉴를 입력해주세요. \n 1. 아메리카노 \t  2. 카페라떼 \t 3. 에스프레소 \t 4. 우유 \t 5. 모닝빵 \n6. 조각케잌 \t 7. 쿠키 \t 8. 마카롱 \t 9. 아이스티 \t 10. 초코라떼");		
			ord = Integer.parseInt(sc.nextLine());				
							
			System.out.println("주문하실 메뉴의 개수를 입력해주세요.");				
			num = Integer.parseInt(sc.nextLine());				
							
			if (ord == 1)	{			
				x = 4000;			
			} else if(ord == 2 )	{			
				x = 5000;			
			} else if(ord == 3 )	{			
				x = 6000;			
			} else if(ord == 4 )	{			
				x = 3000;			
			} else if(ord == 5 )	{			
				x = 2000;			
			} else if(ord == 6 )	{			
				x = 6000;			
			} else if(ord == 7 )	{			
				x = 4000;			
			} else if(ord == 8 )	{			
				x = 2500;			
			} else if(ord == 9 )	{			
				x = 6000;			
			} else if(ord == 10 )	{			
				x = 6000;			
			}				
							
			total += x*num;	// 반복문이 한번 돌때마다 총 금액을 가산하여 total 변수에 저장			
			System.out.println("종료하시겠습니까? 0. 종료 \t 11.계속 \t 12. 멤버십 적립");				
			ord = Integer.parseInt(sc.nextLine());				
							
			if (ord == 12)	{			
				System.out.println("멤버십 아이디를 입력해 주세요");			
				memberID = sc.nextLine();			
				System.out.println("비밀번호를 입력해 주세요");			
				memberPW = sc.nextLine();			
				System.out.println("주문하신 메뉴의 총 금액은 " + total +"원 입니다.");			
				break;			
							
			}				
		System.out.println("주문하신 메뉴의 총 금액은 " + total +"원 입니다.");					
		}					
	}						
}						